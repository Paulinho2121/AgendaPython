from django.shortcuts import render, redirect, get_object_or_404
from contacts.models import Contact, Category
from django.core.paginator import Paginator
from forms import ContactForm

# Create your views here.
def index(request):
    contacts = Contact.objects.all()
    paginator = Paginator(contacts,3)  # Show 25 contacts per page.
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    context = {
        'titulo': 'Homepage',
        'page_obj': page_obj
    }

    return render(
        request,
        'contacts/index.html',
        context
    )

def contact(request, contact_id):
    contact = get_object_or_404(Contact,pl=contact_id)
    context = {
        'titulo': 'Dados do contato',
        'contato': contact
    }
    return render(
        request,
        'contacts/contact.html',
        context
    )

def create(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        context = {
            'titulo': 'New contact',
            'form': form
        }

        if form.is_valid:
            form.save()
            redirect('contact:index')
        
        # If the form has errors...
        return render(
            request,
            'contacts/create.html',
            context
        )

    form = ContactForm(request.POST)
    context = {
        'titulo': 'New contact',
        'form': form
    }
    
    # If the form has errors...
    return render(
        request,
        'contacts/create.html',
        context
    )

def retornar(request):
    contacts = Contact.objects.filter(state = 'Dallas')
    paginator = Paginator(contacts,3)  # Show 25 contacts per page.
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    context = {
        'titulo': 'Homepage',
        'page_obj': page_obj
    }

    return render(
        request,
        'contacts/index.html',
        context
    )