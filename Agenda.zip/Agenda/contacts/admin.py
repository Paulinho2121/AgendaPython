from django.contrib import admin
from contacts import models

# Register your models here.

@admin.register(models.Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('id','first_name','last_name','phone')
    ordering = ('first_name','last_name')
    list_filter = ('first_name',)
    search_fields = ('first_name','phone',)
    list_per_page = 2 # Nº de registos por página
    list_max_show_all = 15
    list_display_links = ('first_name',)

@admin.register(models.Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    ordering = ('-id',)