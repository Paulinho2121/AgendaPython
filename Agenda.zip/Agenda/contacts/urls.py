# Caminho da raíz do site
from django.urls import path
from contacts import views

app_name = 'contact'

urlpatterns = [
    path('', views.index, name='index'),
    path('contact/retornar', views.retornar, name='retornar'),
    path('contact/<int:contact_id>/view/',views.contact,name='view'),
    path('contact/new_contact', views.create, name="create")
]